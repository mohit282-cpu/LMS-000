<?php

/**
 * Enterprise LMS Front Controller (Entry Point)
 * Initializes autoloader, defines routes, handles request routing,
 * executes middleware, and handles global exceptions.
 */

// Error logging setup (prevent showing sensitive errors in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__DIR__) . '/error.log');

// Register Autoloader
require_once dirname(__DIR__) . '/app/Core/Autoloader.php';
App\Core\Autoloader::register();

use App\Core\Router;
use App\Core\Response;
use App\Controllers\AuthController;
use App\Controllers\DashboardController;
use App\Middleware\AuthMiddleware;

try {
    $router = new Router();

    // --- Define Routes ---

    // Root route redirects to dashboard
    $router->get('/', [DashboardController::class, 'index'], [AuthMiddleware::class]);

    // Authentication Routes
    $router->get('/login', [AuthController::class, 'showLogin']);
    $router->post('/login', [AuthController::class, 'login']);
    $router->get('/register', [AuthController::class, 'showRegister']);
    $router->post('/register', [AuthController::class, 'register']);
    $router->get('/logout', [AuthController::class, 'logout']);

    // Guarded Dashboard Routes
    $router->get('/dashboard', [DashboardController::class, 'index'], [AuthMiddleware::class]);

    // Dispatch Route
    $router->resolve();

} catch (\Exception $e) {
    // Write exception to log
    error_log("Global Exception: " . $e->getMessage() . "\n" . $e->getTraceAsString());

    // Send 500 response
    $response = new Response();
    $response->setStatusCode(500);

    // Render detailed errors only if in local development
    $message = "A critical error occurred while processing your request. Please try again later.";
    
    // Check if localhost
    $isLocal = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1']) || 
               str_contains($_SERVER['HTTP_HOST'] ?? '', 'localhost');
               
    if ($isLocal) {
        $message = "Database/Core Error: " . $e->getMessage();
    }

    $view = new App\Core\View();
    $view->setLayout('auth');
    try {
        $view->render('errors/500', [
            'title' => 'Server Error | Enterprise LMS',
            'message' => $message
        ]);
    } catch (\Exception $viewEx) {
        echo "<h1>500 Internal Server Error</h1><p>" . htmlspecialchars($message) . "</p>";
    }
}
