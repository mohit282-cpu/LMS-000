<?php

namespace App\Core;

use PDO;

abstract class Model
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    protected function query(string $sql, array $params = [])
    {
        return Database::query($sql, $params);
    }
}
