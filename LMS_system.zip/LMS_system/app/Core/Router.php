<?php

namespace App\Core;

class Router
{
    private array $routes = [];
    private Request $request;
    private Response $response;
    private Session $session;

    public function __construct()
    {
        $this->request = new Request();
        $this->response = new Response();
        $this->session = new Session();
    }

    public function get(string $path, array $callback, array $middlewares = [])
    {
        $this->routes['GET'][$this->convertToRegex($path)] = [
            'callback' => $callback,
            'middlewares' => $middlewares
        ];
    }

    public function post(string $path, array $callback, array $middlewares = [])
    {
        $this->routes['POST'][$this->convertToRegex($path)] = [
            'callback' => $callback,
            'middlewares' => $middlewares
        ];
    }

    private function convertToRegex(string $path): string
    {
        // Replace {param} with named capturing groups
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[a-zA-Z0-9_\-]+)', $path);
        // Escape slashes and wrap in delimiters
        return '/^' . str_replace('/', '\/', $pattern) . '$/';
    }

    public function resolve()
    {
        $method = $this->request->getMethod();
        $uri = $this->request->getUri();

        if (!isset($this->routes[$method])) {
            $this->handleNotFound();
            return;
        }

        foreach ($this->routes[$method] as $routePattern => $routeInfo) {
            if (preg_match($routePattern, $uri, $matches)) {
                // Extract named matches for route parameters
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                
                $callback = $routeInfo['callback'];
                $middlewares = $routeInfo['middlewares'];

                // Run middlewares
                foreach ($middlewares as $middlewareClass) {
                    $middleware = new $middlewareClass();
                    $middleware->handle($this->request, $this->response, $this->session);
                }

                $controllerClass = $callback[0];
                $action = $callback[1];

                if (class_exists($controllerClass)) {
                    $controller = new $controllerClass();
                    if (method_exists($controller, $action)) {
                        // Call action with path parameters
                        call_user_func_array([$controller, $action], $params);
                        return;
                    }
                }
                
                $this->handleError("Action or Controller does not exist.");
                return;
            }
        }

        $this->handleNotFound();
    }

    private function handleNotFound()
    {
        $this->response->setStatusCode(404);
        $view = new View();
        $view->setLayout('auth'); // use a clean layout for errors
        try {
            $view->render('errors/404', ['title' => 'Page Not Found']);
        } catch (\Exception $e) {
            echo "<h1>404 Not Found</h1>";
        }
    }

    private function handleError(string $message)
    {
        $this->response->setStatusCode(500);
        $view = new View();
        $view->setLayout('auth');
        try {
            $view->render('errors/500', ['title' => 'Server Error', 'message' => $message]);
        } catch (\Exception $e) {
            echo "<h1>500 Server Error</h1><p>" . htmlspecialchars($message) . "</p>";
        }
    }
}
