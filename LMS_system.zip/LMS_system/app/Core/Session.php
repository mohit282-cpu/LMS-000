<?php

namespace App\Core;

class Session
{
    private const FLASH_KEY = 'flash_messages';

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            // Set secure session cookie parameters
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_only_cookies', 1);
            
            // Check if HTTPS is used
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] == 443);
            if ($secure) {
                ini_set('session.cookie_secure', 1);
            }

            session_start();
        }

        // Initialize flash messages array
        if (!isset($_SESSION[self::FLASH_KEY])) {
            $_SESSION[self::FLASH_KEY] = [];
        }

        // Mark existing flash messages as to-be-removed (next request)
        foreach ($_SESSION[self::FLASH_KEY] as $key => &$flash) {
            $flash['remove'] = true;
        }
    }

    public function set(string $key, $value)
    {
        $_SESSION[$key] = $value;
    }

    public function get(string $key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }

    public function remove(string $key)
    {
        unset($_SESSION[$key]);
    }

    public function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    // Flash Messages (available only for the next page load)
    public function setFlash(string $key, string $message, string $type = 'success')
    {
        $_SESSION[self::FLASH_KEY][$key] = [
            'value' => $message,
            'type' => $type,
            'remove' => false
        ];
    }

    public function getFlash(string $key): ?array
    {
        return $_SESSION[self::FLASH_KEY][$key] ?? null;
    }

    public function getFlashes(): array
    {
        return $_SESSION[self::FLASH_KEY] ?? [];
    }

    // CSRF Protection
    public function getCsrfToken(): string
    {
        if (!$this->has('csrf_token')) {
            $token = bin2hex(random_bytes(32));
            $this->set('csrf_token', $token);
        }
        return $this->get('csrf_token');
    }

    public function validateCsrfToken(?string $token): bool
    {
        $stored = $this->get('csrf_token');
        if (!$stored || !$token) {
            return false;
        }
        return hash_equals($stored, $token);
    }

    // Regenerate session id on login/status changes to prevent session fixation
    public function regenerate()
    {
        session_regenerate_id(true);
    }

    public function destroy()
    {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        session_destroy();
    }

    public function __destruct()
    {
        // Cleanup marked flash messages at the end of execution
        if (isset($_SESSION[self::FLASH_KEY])) {
            foreach ($_SESSION[self::FLASH_KEY] as $key => $flash) {
                if ($flash['remove']) {
                    unset($_SESSION[self::FLASH_KEY][$key]);
                }
            }
        }
    }
}
