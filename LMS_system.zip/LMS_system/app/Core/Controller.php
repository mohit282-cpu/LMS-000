<?php

namespace App\Core;

abstract class Controller
{
    protected Request $request;
    protected Response $response;
    protected Session $session;
    protected View $view;

    public function __construct()
    {
        $this->request = new Request();
        $this->response = new Response();
        $this->session = new Session();
        $this->view = new View();
    }

    protected function render(string $viewName, array $data = [])
    {
        // Inject CSRF token and session flashes to all view templates automatically
        $data['csrf_token'] = $this->session->getCsrfToken();
        $data['flashes'] = $this->session->getFlashes();
        $data['currentUser'] = $this->session->get('user');

        $this->view->render($viewName, $data);
    }

    protected function redirect(string $url)
    {
        $this->response->redirect($url);
    }

    protected function json(array $data, int $statusCode = 200)
    {
        $this->response->json($data, $statusCode);
    }

    protected function validateCsrf()
    {
        $token = $this->request->get('csrf_token') ?: ($this->request->get('CSRF_TOKEN') ?: null);
        if (!$this->session->validateCsrfToken($token)) {
            $this->response->setStatusCode(403);
            die("CSRF Token Verification Failed. Request aborted.");
        }
    }
}
