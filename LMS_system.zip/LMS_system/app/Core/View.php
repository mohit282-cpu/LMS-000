<?php

namespace App\Core;

class View
{
    private string $layout = 'main';

    public function setLayout(string $layout)
    {
        $this->layout = $layout;
        return $this;
    }

    public function render(string $view, array $data = [])
    {
        // Extract data elements as variables
        extract($data);

        // Capture view content
        $viewFile = dirname(__DIR__) . "/Views/$view.php";
        if (!file_exists($viewFile)) {
            throw new \Exception("View file not found: $viewFile");
        }

        ob_start();
        include $viewFile;
        $content = ob_get_clean();

        // If no layout is set or layout is empty, just output content
        if (!$this->layout) {
            echo $content;
            return;
        }

        // Capture layout content
        $layoutFile = dirname(__DIR__) . "/Views/layouts/{$this->layout}.php";
        if (!file_exists($layoutFile)) {
            throw new \Exception("Layout file not found: $layoutFile");
        }

        // Session instance is injected into layout so we can display flash messages, auth status
        $session = new Session();

        include $layoutFile;
    }
}
