<?php

namespace App\Core;

class Request
{
    private array $params = [];
    private string $method;
    private string $uri;

    public function __construct()
    {
        $this->method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $this->uri = $this->parseUri();
        $this->bootstrapParams();
    }

    private function parseUri(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        // Strip query string (?foo=bar)
        if (($pos = strpos($uri, '?')) !== false) {
            $uri = substr($uri, 0, $pos);
        }
        return '/' . trim($uri, '/');
    }

    private function bootstrapParams()
    {
        // GET params
        foreach ($_GET as $key => $val) {
            $this->params[$key] = $this->sanitize($val);
        }

        // POST params
        if ($this->method === 'POST') {
            foreach ($_POST as $key => $val) {
                $this->params[$key] = $this->sanitize($val);
            }

            // Raw input (JSON)
            $raw = file_get_contents('php://input');
            if (!empty($raw)) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $key => $val) {
                        $this->params[$key] = $this->sanitize($val);
                    }
                }
            }
        }
    }

    private function sanitize($value)
    {
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $value[$k] = $this->sanitize($v);
            }
            return $value;
        }
        
        if (is_string($value)) {
            // Trim and escape HTML to prevent XSS
            return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }

        return $value;
    }

    public function getMethod(): string
    {
        return $this->method;
    }

    public function getUri(): string
    {
        return $this->uri;
    }

    public function get(string $key, $default = null)
    {
        return $this->params[$key] ?? $default;
    }

    public function all(): array
    {
        return $this->params;
    }

    public function isPost(): bool
    {
        return $this->method === 'POST';
    }

    public function isGet(): bool
    {
        return $this->method === 'GET';
    }
}
