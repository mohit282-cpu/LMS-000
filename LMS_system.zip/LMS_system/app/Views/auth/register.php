<div class="auth-container">
    <div class="auth-card glass-panel" style="max-width: 540px;">
        <div class="auth-logo">
            <div class="brand-icon">L</div>
            <span class="brand-text">Enterprise LMS</span>
        </div>
        
        <h2 class="auth-title">Create Account</h2>
        <p class="auth-subtitle">Join our enterprise learning platform</p>

        <!-- Display registration errors if any -->
        <?php if (isset($flashes['register_error'])): ?>
            <div class="alert alert-danger border-0 text-white p-3 mb-4 rounded" style="background: hsla(354, 91%, 60%, 0.2); border-left: 4px solid var(--danger) !important;">
                <i class="fas fa-circle-exclamation me-2"></i> <?= htmlspecialchars($flashes['register_error']['value']) ?>
            </div>
        <?php endif; ?>

        <form action="/register" method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="name" class="form-label">Full Name</label>
                    <input type="text" id="name" name="name" class="form-input" placeholder="John Doe" required>
                </div>
                <div class="col-md-6 form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" id="email" name="email" class="form-input" placeholder="john@doe.com" required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="phone" class="form-label">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="form-input" placeholder="+123456789">
                </div>
                <div class="col-md-6 form-group">
                    <label for="role" class="form-label">Account Role</label>
                    <select id="role" name="role" class="form-input" style="background-image: none; cursor: pointer;">
                        <option value="Student">Student (Learner)</option>
                        <option value="Teacher">Teacher (Instructor)</option>
                        <option value="Admin">Administrator</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-input" placeholder="••••••••" required>
            </div>

            <button type="submit" class="btn-premium mt-2">
                <span>Sign Up</span>
                <i class="fa-solid fa-user-plus"></i>
            </button>
        </form>

        <div class="auth-footer">
            Already have an account? <a href="/login">Sign In</a>
        </div>
    </div>
</div>
