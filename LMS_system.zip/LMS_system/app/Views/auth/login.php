<div class="auth-container">
    <div class="auth-card glass-panel">
        <div class="auth-logo">
            <div class="brand-icon">L</div>
            <span class="brand-text">Enterprise LMS</span>
        </div>
        
        <h2 class="auth-title">Welcome Back</h2>
        <p class="auth-subtitle">Sign in to your learning dashboard</p>

        <!-- Display local login errors if any -->
        <?php if (isset($flashes['login_error'])): ?>
            <div class="alert alert-danger border-0 text-white p-3 mb-4 rounded" style="background: hsla(354, 91%, 60%, 0.2); border-left: 4px solid var(--danger) !important;">
                <i class="fas fa-circle-exclamation me-2"></i> <?= htmlspecialchars($flashes['login_error']['value']) ?>
            </div>
        <?php endif; ?>
        <?php if (isset($flashes['login_success'])): ?>
            <div class="alert alert-success border-0 text-white p-3 mb-4 rounded" style="background: hsla(145, 63%, 49%, 0.2); border-left: 4px solid var(--success) !important;">
                <i class="fas fa-circle-check me-2"></i> <?= htmlspecialchars($flashes['login_success']['value']) ?>
            </div>
        <?php endif; ?>

        <form action="/login" method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            
            <div class="form-group">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" id="email" name="email" class="form-input" placeholder="name@lms.com" required autocomplete="email">
            </div>

            <div class="form-group">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <label for="password" class="form-label m-0">Password</label>
                    <a href="#" class="text-decoration-none" style="font-size: 0.8rem; color: var(--primary);">Forgot?</a>
                </div>
                <input type="password" id="password" name="password" class="form-input" placeholder="••••••••" required autocomplete="current-password">
            </div>

            <button type="submit" class="btn-premium mt-2">
                <span>Sign In</span>
                <i class="fa-solid fa-arrow-right"></i>
            </button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="/register">Create one</a>
        </div>
    </div>
</div>
