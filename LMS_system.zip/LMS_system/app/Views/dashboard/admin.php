<div class="container-fluid p-0 animate-fade-in">
    <!-- Top Widgets Row -->
    <div class="row g-4">
        <!-- Widget 1: Total Users -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= number_format($stats['total_users']) ?></h3>
                    <p>Total Registered Users</p>
                </div>
                <div class="stat-icon" style="background: rgba(52, 152, 219, 0.1); color: var(--primary);">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
        </div>
        
        <!-- Widget 2: Active Users -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= number_format($stats['active_users']) ?></h3>
                    <p>Active User Sessions</p>
                </div>
                <div class="stat-icon" style="background: rgba(46, 204, 113, 0.1); color: var(--success);">
                    <i class="fa-solid fa-user-check"></i>
                </div>
            </div>
        </div>

        <!-- Widget 3: Active Courses -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= number_format($stats['total_courses']) ?></h3>
                    <p>Active LMS Courses</p>
                </div>
                <div class="stat-icon" style="background: rgba(155, 89, 182, 0.1); color: var(--secondary);">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
            </div>
        </div>

        <!-- Widget 4: Audit Logs -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= number_format($stats['total_logs']) ?></h3>
                    <p>Logged Events</p>
                </div>
                <div class="stat-icon" style="background: rgba(230, 126, 34, 0.1); color: var(--warning);">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Tables Row -->
    <div class="row g-4 mt-2">
        <!-- Left Table: Recent Users -->
        <div class="col-xl-6">
            <div class="data-table-container glass-panel mt-0">
                <div class="table-header-panel">
                    <h5 class="m-0 font-heading"><i class="fa-solid fa-user-plus me-2 text-primary"></i>Recent Users</h5>
                    <button class="btn btn-sm btn-outline-secondary" style="border-radius: var(--border-radius-sm);">View All</button>
                </div>
                <div class="table-responsive">
                    <table class="table-premium">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentUsers as $user): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="profile-avatar" style="width: 32px; height: 32px; font-size: 0.85rem;">
                                                <?= htmlspecialchars(strtoupper(substr($user['name'], 0, 1))) ?>
                                            </div>
                                            <strong><?= htmlspecialchars($user['name']) ?></strong>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td>
                                        <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-2 py-1 rounded" style="font-size: 0.75rem;">
                                            <?= htmlspecialchars($user['role'] ?? 'Student') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge-status <?= htmlspecialchars($user['status']) ?>">
                                            <?= htmlspecialchars($user['status']) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Right Table: Recent Audit Logs -->
        <div class="col-xl-6">
            <div class="data-table-container glass-panel mt-0">
                <div class="table-header-panel">
                    <h5 class="m-0 font-heading"><i class="fa-solid fa-clock-rotate-left me-2 text-warning"></i>Security logs</h5>
                    <button class="btn btn-sm btn-outline-secondary" style="border-radius: var(--border-radius-sm);">Export</button>
                </div>
                <div class="table-responsive">
                    <table class="table-premium">
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>User / Context</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentLogs as $log): ?>
                                <tr>
                                    <td>
                                        <strong class="<?= str_contains($log['action'], 'SUCCESS') ? 'text-success' : (str_contains($log['action'], 'FAILURE') ? 'text-danger' : 'text-primary') ?>">
                                            <?= htmlspecialchars($log['action']) ?>
                                        </strong>
                                    </td>
                                    <td>
                                        <div>
                                            <small class="text-white d-block"><?= htmlspecialchars($log['description']) ?></small>
                                            <small class="text-muted"><?= htmlspecialchars($log['ip_address'] ?? 'N/A') ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?= date('M d, H:i:s', strtotime($log['created_at'])) ?></small>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
