<div class="container-fluid p-0 animate-fade-in">
    <!-- Top Widgets Row -->
    <div class="row g-4">
        <!-- Widget 1: Enrolled Courses -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['my_courses']) ?></h3>
                    <p>Enrolled Courses</p>
                </div>
                <div class="stat-icon" style="background: rgba(52, 152, 219, 0.1); color: var(--primary);">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
            </div>
        </div>
        
        <!-- Widget 2: Pending Quizzes -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['pending_quizzes']) ?></h3>
                    <p>Pending Quizzes</p>
                </div>
                <div class="stat-icon" style="background: rgba(230, 126, 34, 0.1); color: var(--warning);">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
            </div>
        </div>

        <!-- Widget 3: Submitted Work -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['submitted_assignments']) ?></h3>
                    <p>Submitted Items</p>
                </div>
                <div class="stat-icon" style="background: rgba(46, 204, 113, 0.1); color: var(--success);">
                    <i class="fa-solid fa-square-check"></i>
                </div>
            </div>
        </div>

        <!-- Widget 4: GPA -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['current_gpa']) ?></h3>
                    <p>Cumulative GPA</p>
                </div>
                <div class="stat-icon" style="background: rgba(155, 89, 182, 0.1); color: var(--secondary);">
                    <i class="fa-solid fa-star"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Student Details Grid Content -->
    <div class="row g-4 mt-2">
        <!-- Courses & Progress -->
        <div class="col-lg-8">
            <div class="data-table-container glass-panel mt-0">
                <div class="table-header-panel">
                    <h5 class="m-0 font-heading"><i class="fa-solid fa-layer-group me-2 text-primary"></i>My Enrolled Courses & Progress</h5>
                </div>
                <div class="p-4">
                    <!-- Course 1 -->
                    <div class="mb-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-white"><strong>CS-302: Web Application Architecture</strong></span>
                            <span class="text-muted">85% Complete</span>
                        </div>
                        <div class="progress" style="height: 8px; background: rgba(255, 255, 255, 0.05); border-radius: 5px;">
                            <div class="progress-bar" role="progressbar" style="width: 85%; background: linear-gradient(to right, var(--primary), var(--secondary));" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <!-- Course 2 -->
                    <div class="mb-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-white"><strong>CS-301: Database Management Systems</strong></span>
                            <span class="text-muted">65% Complete</span>
                        </div>
                        <div class="progress" style="height: 8px; background: rgba(255, 255, 255, 0.05); border-radius: 5px;">
                            <div class="progress-bar" role="progressbar" style="width: 65%; background: linear-gradient(to right, var(--primary), var(--secondary));" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <!-- Course 3 -->
                    <div class="mb-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-white"><strong>CS-405: Cloud Security Systems</strong></span>
                            <span class="text-muted">45% Complete</span>
                        </div>
                        <div class="progress" style="height: 8px; background: rgba(255, 255, 255, 0.05); border-radius: 5px;">
                            <div class="progress-bar" role="progressbar" style="width: 45%; background: linear-gradient(to right, var(--primary), var(--secondary));" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <!-- Course 4 -->
                    <div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-white"><strong>CS-204: Discrete Mathematics</strong></span>
                            <span class="text-muted">90% Complete</span>
                        </div>
                        <div class="progress" style="height: 8px; background: rgba(255, 255, 255, 0.05); border-radius: 5px;">
                            <div class="progress-bar" role="progressbar" style="width: 90%; background: linear-gradient(to right, var(--primary), var(--secondary));" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side: Tasks & Deadlines -->
        <div class="col-lg-4">
            <div class="data-table-container glass-panel mt-0">
                <div class="table-header-panel">
                    <h5 class="m-0 font-heading"><i class="fa-solid fa-circle-exclamation me-2 text-danger"></i>Upcoming Deadlines</h5>
                </div>
                <div class="p-3">
                    <div class="d-flex flex-column gap-3">
                        <div class="p-3 rounded border border-light-subtle d-flex gap-3 align-items-center" style="background: rgba(255, 255, 255, 0.02);">
                            <div class="text-center p-2 rounded" style="background: rgba(231, 76, 60, 0.15); color: var(--danger); min-width: 60px;">
                                <h4 class="m-0 font-heading">05</h4>
                                <small style="font-size: 0.7rem; text-transform: uppercase;">Jul</small>
                            </div>
                            <div>
                                <strong class="text-white d-block" style="font-size: 0.9rem;">Assignment 4 (Router Setup)</strong>
                                <small class="text-muted">CS-302 - Due 11:59 PM</small>
                            </div>
                        </div>

                        <div class="p-3 rounded border border-light-subtle d-flex gap-3 align-items-center" style="background: rgba(255, 255, 255, 0.02);">
                            <div class="text-center p-2 rounded" style="background: rgba(230, 126, 34, 0.15); color: var(--warning); min-width: 60px;">
                                <h4 class="m-0 font-heading">08</h4>
                                <small style="font-size: 0.7rem; text-transform: uppercase;">Jul</small>
                            </div>
                            <div>
                                <strong class="text-white d-block" style="font-size: 0.9rem;">Midterm Quiz (DB Design)</strong>
                                <small class="text-muted">CS-301 - Due 02:00 PM</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
