<div class="container-fluid p-0 animate-fade-in">
    <!-- Top Widgets Row -->
    <div class="row g-4">
        <!-- Widget 1: My Subjects -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['my_subjects']) ?></h3>
                    <p>Assigned Subjects</p>
                </div>
                <div class="stat-icon" style="background: rgba(155, 89, 182, 0.1); color: var(--secondary);">
                    <i class="fa-solid fa-book"></i>
                </div>
            </div>
        </div>
        
        <!-- Widget 2: Enrolled Students -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['total_students']) ?></h3>
                    <p>Total Enrolled Students</p>
                </div>
                <div class="stat-icon" style="background: rgba(52, 152, 219, 0.1); color: var(--primary);">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
        </div>

        <!-- Widget 3: Pending Submissions -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['pending_assignments']) ?></h3>
                    <p>Pending Assignments</p>
                </div>
                <div class="stat-icon" style="background: rgba(230, 126, 34, 0.1); color: var(--warning);">
                    <i class="fa-solid fa-clock"></i>
                </div>
            </div>
        </div>

        <!-- Widget 4: GPA -->
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-info">
                    <h3><?= htmlspecialchars($stats['average_gpa']) ?></h3>
                    <p>Class Average GPA</p>
                </div>
                <div class="stat-icon" style="background: rgba(46, 204, 113, 0.1); color: var(--success);">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Interactive Grid Content -->
    <div class="row g-4 mt-2">
        <!-- Classes listing -->
        <div class="col-lg-7">
            <div class="data-table-container glass-panel mt-0">
                <div class="table-header-panel">
                    <h5 class="m-0 font-heading"><i class="fa-solid fa-chalkboard-user me-2 text-primary"></i>My Assigned Classes</h5>
                    <button class="btn btn-sm btn-outline-primary" style="border-radius: var(--border-radius-sm);">Manage Classes</button>
                </div>
                <div class="table-responsive">
                    <table class="table-premium">
                        <thead>
                            <tr>
                                <th>Subject Code</th>
                                <th>Subject Title</th>
                                <th>Schedule</th>
                                <th>Room</th>
                                <th>Students</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>CS-301</strong></td>
                                <td>Database Management Systems</td>
                                <td>Mon/Wed 10:00 AM</td>
                                <td>Lab B</td>
                                <td>32</td>
                            </tr>
                            <tr>
                                <td><strong>CS-302</strong></td>
                                <td>Web Application Architecture</td>
                                <td>Tue/Thu 02:00 PM</td>
                                <td>Room 402</td>
                                <td>45</td>
                            </tr>
                            <tr>
                                <td><strong>CS-405</strong></td>
                                <td>Cloud Security Systems</td>
                                <td>Fri 09:00 AM</td>
                                <td>Lab D</td>
                                <td>26</td>
                            </tr>
                            <tr>
                                <td><strong>CS-204</strong></td>
                                <td>Discrete Mathematics</td>
                                <td>Mon/Wed 04:00 PM</td>
                                <td>Room 101</td>
                                <td>25</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Recent Submissions list -->
        <div class="col-lg-5">
            <div class="data-table-container glass-panel mt-0">
                <div class="table-header-panel">
                    <h5 class="m-0 font-heading"><i class="fa-solid fa-file-invoice me-2 text-warning"></i>Recent Assignment Submissions</h5>
                </div>
                <div class="p-3">
                    <div class="d-flex flex-column gap-3">
                        <div class="p-3 rounded border border-light-subtle" style="background: rgba(255, 255, 255, 0.02);">
                            <div class="d-flex justify-content-between mb-1">
                                <strong class="text-white">Jane Smith</strong>
                                <span class="badge bg-warning-subtle text-warning" style="font-size: 0.75rem;">Submitted Today</span>
                            </div>
                            <small class="text-muted d-block mb-2">CS-302: Assignment 3 - MVC Setup</small>
                            <button class="btn btn-xs btn-primary py-1 px-2" style="font-size: 0.8rem; border-radius: var(--border-radius-sm);">Review & Grade</button>
                        </div>
                        
                        <div class="p-3 rounded border border-light-subtle" style="background: rgba(255, 255, 255, 0.02);">
                            <div class="d-flex justify-content-between mb-1">
                                <strong class="text-white">Alex Johnson</strong>
                                <span class="badge bg-warning-subtle text-warning" style="font-size: 0.75rem;">Submitted Yesterday</span>
                            </div>
                            <small class="text-muted d-block mb-2">CS-301: Assignment 2 - SQL Joins</small>
                            <button class="btn btn-xs btn-primary py-1 px-2" style="font-size: 0.8rem; border-radius: var(--border-radius-sm);">Review & Grade</button>
                        </div>

                        <div class="p-3 rounded border border-light-subtle" style="background: rgba(255, 255, 255, 0.02);">
                            <div class="d-flex justify-content-between mb-1">
                                <strong class="text-white">Sarah Lee</strong>
                                <span class="badge bg-success-subtle text-success" style="font-size: 0.75rem;">Graded</span>
                            </div>
                            <small class="text-muted d-block mb-2">CS-405: Research Paper Proposal</small>
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <span class="text-white font-weight-bold" style="font-size: 0.9rem;">Grade: 95/100</span>
                                <a href="#" style="font-size: 0.8rem; color: var(--primary);">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
