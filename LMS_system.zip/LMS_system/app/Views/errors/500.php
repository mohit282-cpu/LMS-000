<div class="auth-container">
    <div class="auth-card glass-panel text-center">
        <div class="auth-logo">
            <div class="brand-icon" style="background: linear-gradient(135deg, var(--danger), var(--secondary)); box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);">
                <i class="fa-solid fa-bug"></i>
            </div>
        </div>
        <h1 class="font-heading text-danger mb-2" style="font-size: 4rem;">500</h1>
        <h3 class="font-heading mb-3">Internal Server Error</h3>
        <p class="text-muted mb-4"><?= htmlspecialchars($message ?? 'An unexpected error occurred on our server. Please try again later.') ?></p>
        <a href="/dashboard" class="btn-premium">
            <i class="fa-solid fa-arrow-left-long"></i> Back to Safety
        </a>
    </div>
</div>
