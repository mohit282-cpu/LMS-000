<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Enterprise LMS') ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom Design CSS -->
    <link href="/css/style.css" rel="stylesheet">
</head>
<body>

    <!-- Toast Notifications Container -->
    <div class="toast-container">
        <?php foreach ($flashes as $key => $flash): ?>
            <div class="premium-alert <?= htmlspecialchars($flash['type']) ?>">
                <i class="fas <?= $flash['type'] === 'success' ? 'fa-check-circle' : ($flash['type'] === 'danger' ? 'fa-exclamation-circle' : 'fa-info-circle') ?>"></i>
                <span><?= htmlspecialchars($flash['value']) ?></span>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="app-container">
        <!-- Sidebar Navigation -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-brand">
                <div class="brand-icon">L</div>
                <span class="brand-text">Enterprise LMS</span>
            </div>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="/dashboard" class="sidebar-link <?= ($activePage ?? '') === 'dashboard' ? 'active' : '' ?>">
                        <i class="fa-solid fa-chart-pie"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <!-- Role specific sidebar links -->
                <?php if ($currentUser && $currentUser['role'] === 'Admin'): ?>
                    <li>
                        <a href="/users" class="sidebar-link <?= ($activePage ?? '') === 'users' ? 'active' : '' ?>">
                            <i class="fa-solid fa-users-gear"></i>
                            <span>User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="/courses" class="sidebar-link <?= ($activePage ?? '') === 'courses' ? 'active' : '' ?>">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <span>Course Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="/settings" class="sidebar-link <?= ($activePage ?? '') === 'settings' ? 'active' : '' ?>">
                            <i class="fa-solid fa-sliders"></i>
                            <span>System Settings</span>
                        </a>
                    </li>
                    <li>
                        <a href="/logs" class="sidebar-link <?= ($activePage ?? '') === 'logs' ? 'active' : '' ?>">
                            <i class="fa-solid fa-shield-halved"></i>
                            <span>Audit Logs</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($currentUser && $currentUser['role'] === 'Teacher'): ?>
                    <li>
                        <a href="/subjects" class="sidebar-link <?= ($activePage ?? '') === 'subjects' ? 'active' : '' ?>">
                            <i class="fa-solid fa-book-open"></i>
                            <span>Subject Manager</span>
                        </a>
                    </li>
                    <li>
                        <a href="/attendance" class="sidebar-link <?= ($activePage ?? '') === 'attendance' ? 'active' : '' ?>">
                            <i class="fa-solid fa-calendar-check"></i>
                            <span>Take Attendance</span>
                        </a>
                    </li>
                    <li>
                        <a href="/assignments" class="sidebar-link <?= ($activePage ?? '') === 'assignments' ? 'active' : '' ?>">
                            <i class="fa-solid fa-file-pen"></i>
                            <span>Assignments</span>
                        </a>
                    </li>
                    <li>
                        <a href="/results" class="sidebar-link <?= ($activePage ?? '') === 'results' ? 'active' : '' ?>">
                            <i class="fa-solid fa-square-poll-vertical"></i>
                            <span>Grade Results</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($currentUser && $currentUser['role'] === 'Student'): ?>
                    <li>
                        <a href="/my-courses" class="sidebar-link <?= ($activePage ?? '') === 'my-courses' ? 'active' : '' ?>">
                            <i class="fa-solid fa-book"></i>
                            <span>My Courses</span>
                        </a>
                    </li>
                    <li>
                        <a href="/my-assignments" class="sidebar-link <?= ($activePage ?? '') === 'my-assignments' ? 'active' : '' ?>">
                            <i class="fa-solid fa-circle-info"></i>
                            <span>My Assignments</span>
                        </a>
                    </li>
                    <li>
                        <a href="/grades" class="sidebar-link <?= ($activePage ?? '') === 'grades' ? 'active' : '' ?>">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <span>Grades & Transcript</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- Sidebar User Profile -->
            <div class="sidebar-profile">
                <div class="profile-avatar">
                    <?= htmlspecialchars(strtoupper(substr($currentUser['name'] ?? 'U', 0, 1))) ?>
                </div>
                <div class="profile-info">
                    <span class="profile-name"><?= htmlspecialchars($currentUser['name'] ?? 'User') ?></span>
                    <span class="profile-role"><?= htmlspecialchars($currentUser['role'] ?? 'Guest') ?></span>
                </div>
            </div>
        </aside>

        <!-- Main Wrapper -->
        <div class="main-wrapper">
            <!-- Top Navbar -->
            <header class="top-navbar">
                <div class="navbar-left">
                    <button class="menu-toggle" id="sidebar-toggle">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <h4 class="m-0 font-heading"><?= htmlspecialchars($title ?? 'Dashboard') ?></h4>
                </div>
                
                <div class="navbar-right">
                    <!-- Light/Dark Switcher -->
                    <button class="theme-toggle-btn" id="theme-toggle" title="Toggle Theme">
                        <i class="fa-solid fa-sun"></i>
                    </button>

                    <!-- Log Out Icon Link -->
                    <a href="/logout" class="theme-toggle-btn" title="Log Out" style="text-decoration: none;">
                        <i class="fa-solid fa-right-from-bracket" style="color: var(--danger);"></i>
                    </a>
                </div>
            </header>

            <!-- Page Content Body -->
            <main class="content-body">
                <?= $content ?>
            </main>

            <!-- Footer -->
            <footer>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <p class="m-0">&copy; <?= date('Y') ?> Enterprise LMS. All rights reserved. Designed for scalability and high-performance.</p>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme JS -->
    <script src="/js/dashboard.js"></script>
</body>
</html>
