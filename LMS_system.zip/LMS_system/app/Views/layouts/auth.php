<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Enterprise LMS') ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom Design CSS -->
    <link href="/css/style.css" rel="stylesheet">
</head>
<body>

    <!-- Toast Notifications Container -->
    <div class="toast-container">
        <?php foreach ($flashes as $key => $flash): ?>
            <div class="premium-alert <?= htmlspecialchars($flash['type']) ?>">
                <i class="fas <?= $flash['type'] === 'success' ? 'fa-check-circle' : ($flash['type'] === 'danger' ? 'fa-exclamation-circle' : 'fa-info-circle') ?>"></i>
                <span><?= htmlspecialchars($flash['value']) ?></span>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Layout Content -->
    <?= $content ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme JS -->
    <script src="/js/dashboard.js"></script>
</body>
</html>
