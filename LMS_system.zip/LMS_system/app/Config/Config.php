<?php

namespace App\Config;

class Config
{
    public static function get(string $key, $default = null)
    {
        $config = [
            'db' => [
                'host' => '127.0.0.1',
                'name' => 'lms_db',
                'user' => 'root',
                'pass' => '',
                'charset' => 'utf8mb4'
            ],
            'app' => [
                'name' => 'Enterprise LMS',
                'url' => 'http://localhost:8000',
                'allow_registration' => true // Set to false to disable public signup in production
            ]
        ];

        $parts = explode('.', $key);
        $value = $config;

        foreach ($parts as $part) {
            if (isset($value[$part])) {
                $value = $value[$part];
            } else {
                return $default;
            }
        }

        return $value;
    }
}
