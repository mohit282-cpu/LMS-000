<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use PDO;

class DashboardController extends Controller
{
    public function index()
    {
        $user = $this->session->get('user');

        if (!$user) {
            $this->redirect('/login');
        }

        switch ($user['role']) {
            case 'Admin':
                $this->renderAdminDashboard($user);
                break;
            case 'Teacher':
                $this->renderTeacherDashboard($user);
                break;
            case 'Student':
                $this->renderStudentDashboard($user);
                break;
            default:
                $this->session->destroy();
                $this->redirect('/login');
        }
    }

    private function renderAdminDashboard(array $user)
    {
        // Fetch Admin Statistics
        $totalUsers = Database::query("SELECT COUNT(*) FROM users")->fetchColumn();
        $totalLogs = Database::query("SELECT COUNT(*) FROM audit_logs")->fetchColumn();
        $activeUsers = Database::query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn();

        // Fetch recent audit logs (joined with users)
        $sqlLogs = "SELECT al.*, u.name as user_name, u.email as user_email 
                    FROM audit_logs al 
                    LEFT JOIN users u ON al.user_id = u.id 
                    ORDER BY al.created_at DESC 
                    LIMIT 8";
        $recentLogs = Database::query($sqlLogs)->fetchAll();

        // Fetch user listing to show in summary table
        $sqlUsers = "SELECT u.*, r.name as role 
                     FROM users u
                     LEFT JOIN user_roles ur ON u.id = ur.user_id
                     LEFT JOIN roles r ON ur.role_id = r.id
                     ORDER BY u.created_at DESC 
                     LIMIT 5";
        $recentUsers = Database::query($sqlUsers)->fetchAll();

        $this->render('dashboard/admin', [
            'title' => 'Admin Dashboard | Enterprise LMS',
            'activePage' => 'dashboard',
            'stats' => [
                'total_users' => $totalUsers,
                'total_logs' => $totalLogs,
                'active_users' => $activeUsers,
                'total_courses' => 12 // Simulated course count
            ],
            'recentLogs' => $recentLogs,
            'recentUsers' => $recentUsers
        ]);
    }

    private function renderTeacherDashboard(array $user)
    {
        $this->render('dashboard/teacher', [
            'title' => 'Instructor Dashboard | Enterprise LMS',
            'activePage' => 'dashboard',
            'stats' => [
                'my_subjects' => 4,
                'total_students' => 128,
                'pending_assignments' => 18,
                'average_gpa' => '3.42'
            ]
        ]);
    }

    private function renderStudentDashboard(array $user)
    {
        $this->render('dashboard/student', [
            'title' => 'Student Portal | Enterprise LMS',
            'activePage' => 'dashboard',
            'stats' => [
                'my_courses' => 6,
                'pending_quizzes' => 2,
                'submitted_assignments' => 15,
                'current_gpa' => '3.85'
            ]
        ]);
    }
}
