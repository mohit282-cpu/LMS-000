<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Config\Config;
use PDO;

class AuthController extends Controller
{
    public function showLogin()
    {
        // Redirect to dashboard if already logged in
        if ($this->session->has('user')) {
            $this->redirect('/dashboard');
        }

        $this->view->setLayout('auth');
        $this->render('auth/login', [
            'title' => 'Login | Enterprise LMS'
        ]);
    }

    public function login()
    {
        $this->validateCsrf();

        $email = $this->request->get('email');
        $password = $this->request->get('password');

        if (empty($email) || empty($password)) {
            $this->session->setFlash('login_error', 'Please fill in all fields.', 'danger');
            $this->redirect('/login');
        }

        // Fetch user and their role
        $sql = "SELECT u.*, r.name AS role 
                FROM users u
                LEFT JOIN user_roles ur ON u.id = ur.user_id
                LEFT JOIN roles r ON ur.role_id = r.id
                WHERE u.email = :email AND u.status = 'active'
                LIMIT 1";
        
        $stmt = Database::query($sql, ['email' => $email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            // Write to audit log
            Database::query(
                "INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (:user_id, :action, :description, :ip, :ua)",
                [
                    'user_id' => $user['id'],
                    'action' => 'LOGIN_SUCCESS',
                    'description' => "User {$user['email']} logged in successfully.",
                    'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
                ]
            );

            // Set session data
            $this->session->regenerate();
            $this->session->set('user', [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'role' => $user['role'] ?? 'Student'
            ]);

            $this->session->setFlash('auth_success', "Welcome back, {$user['name']}!", 'success');
            $this->redirect('/dashboard');
        } else {
            // Log failure (without user_id since it might be invalid)
            Database::query(
                "INSERT INTO audit_logs (action, description, ip_address, user_agent) VALUES (:action, :description, :ip, :ua)",
                [
                    'action' => 'LOGIN_FAILURE',
                    'description' => "Failed login attempt for email: " . htmlspecialchars($email),
                    'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
                ]
            );

            $this->session->setFlash('login_error', 'Invalid email or password.', 'danger');
            $this->redirect('/login');
        }
    }

    public function showRegister()
    {
        if (!Config::get('app.allow_registration', true)) {
            $this->session->setFlash('auth_error', 'Public registration is disabled.', 'danger');
            $this->redirect('/login');
        }

        $this->view->setLayout('auth');
        $this->render('auth/register', [
            'title' => 'Register | Enterprise LMS'
        ]);
    }

    public function register()
    {
        if (!Config::get('app.allow_registration', true)) {
            $this->session->setFlash('auth_error', 'Public registration is disabled.', 'danger');
            $this->redirect('/login');
        }

        $this->validateCsrf();

        $name = $this->request->get('name');
        $email = $this->request->get('email');
        $password = $this->request->get('password');
        $phone = $this->request->get('phone');
        $requestedRole = $this->request->get('role', 'Student'); // default to student

        if (empty($name) || empty($email) || empty($password)) {
            $this->session->setFlash('register_error', 'Name, email and password are required.', 'danger');
            $this->redirect('/register');
        }

        // Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->session->setFlash('register_error', 'Invalid email format.', 'danger');
            $this->redirect('/register');
        }

        // Check if email already exists
        $stmt = Database::query("SELECT id FROM users WHERE email = :email LIMIT 1", ['email' => $email]);
        if ($stmt->fetch()) {
            $this->session->setFlash('register_error', 'Email is already registered.', 'danger');
            $this->redirect('/register');
        }

        try {
            $db = Database::connect();
            $db->beginTransaction();

            // Insert user
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmtInsert = $db->prepare("INSERT INTO users (name, email, password_hash, phone, status) VALUES (:name, :email, :password, :phone, 'active')");
            $stmtInsert->execute([
                'name' => $name,
                'email' => $email,
                'password' => $hash,
                'phone' => $phone
            ]);
            $userId = $db->lastInsertId();

            // Get role ID
            $stmtRole = $db->prepare("SELECT id FROM roles WHERE name = :role LIMIT 1");
            $stmtRole->execute(['role' => $requestedRole]);
            $roleId = $stmtRole->fetchColumn();

            if (!$roleId) {
                // Default to Student if requested role not found
                $stmtRole->execute(['role' => 'Student']);
                $roleId = $stmtRole->fetchColumn();
            }

            // Assign role
            $stmtAssign = $db->prepare("INSERT INTO user_roles (user_id, role_id) VALUES (:user_id, :role_id)");
            $stmtAssign->execute(['user_id' => $userId, 'role_id' => $roleId]);

            // Log registration success
            $db->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (:user_id, :action, :description, :ip, :ua)")
               ->execute([
                   'user_id' => $userId,
                   'action' => 'REGISTER_SUCCESS',
                   'description' => "User {$email} registered as a {$requestedRole}.",
                   'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                   'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
               ]);

            $db->commit();

            $this->session->setFlash('login_success', 'Registration successful! You can now log in.', 'success');
            $this->redirect('/login');

        } catch (\Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $this->session->setFlash('register_error', 'An error occurred during registration: ' . $e->getMessage(), 'danger');
            $this->redirect('/register');
        }
    }

    public function logout()
    {
        $user = $this->session->get('user');
        if ($user) {
            Database::query(
                "INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (:user_id, :action, :description, :ip, :ua)",
                [
                    'user_id' => $user['id'],
                    'action' => 'LOGOUT',
                    'description' => "User {$user['email']} logged out.",
                    'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
                ]
            );
        }

        $this->session->destroy();
        // Set flash message on a new session instance after destruction
        $newSession = new \App\Core\Session();
        $newSession->setFlash('login_success', 'You have been successfully logged out.', 'success');
        $this->redirect('/login');
    }
}
