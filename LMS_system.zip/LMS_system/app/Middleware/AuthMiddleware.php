<?php

namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

class AuthMiddleware
{
    public function handle(Request $request, Response $response, Session $session)
    {
        if (!$session->has('user')) {
            $session->setFlash('auth_error', 'Please log in to access this page.', 'danger');
            $response->redirect('/login');
        }
    }
}
