<?php

namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

class AdminMiddleware
{
    public function handle(Request $request, Response $response, Session $session)
    {
        $user = $session->get('user');
        if (!$user || $user['role'] !== 'Admin') {
            $session->setFlash('auth_error', 'Access Denied. Admin privileges required.', 'danger');
            $response->redirect('/dashboard');
        }
    }
}
