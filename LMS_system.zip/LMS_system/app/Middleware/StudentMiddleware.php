<?php

namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

class StudentMiddleware
{
    public function handle(Request $request, Response $response, Session $session)
    {
        $user = $session->get('user');
        if (!$user || !in_array($user['role'], ['Student', 'Admin'])) {
            $session->setFlash('auth_error', 'Access Denied. Student privileges required.', 'danger');
            $response->redirect('/dashboard');
        }
    }
}
