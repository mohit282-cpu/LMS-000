<?php

namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

class TeacherMiddleware
{
    public function handle(Request $request, Response $response, Session $session)
    {
        $user = $session->get('user');
        if (!$user || !in_array($user['role'], ['Teacher', 'Admin'])) {
            $session->setFlash('auth_error', 'Access Denied. Teacher privileges required.', 'danger');
            $response->redirect('/dashboard');
        }
    }
}
