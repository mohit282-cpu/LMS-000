<?php

require_once __DIR__ . '/../app/Core/Autoloader.php';
App\Core\Autoloader::register();

use App\Config\Config;

echo "=========================================\n";
echo "       Enterprise LMS Database Setup      \n";
echo "=========================================\n\n";

$host = Config::get('db.host', '127.0.0.1');
$user = Config::get('db.user', 'root');
$pass = Config::get('db.pass', '');
$dbName = Config::get('db.name', 'lms_db');

try {
    // Connect to MySQL server first (without database)
    echo "Connecting to MySQL server at $host...\n";
    $pdo = new PDO("mysql:host=$host", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Create database if not exists
    echo "Creating database '$dbName' if it doesn't exist...\n";
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $pdo->exec("USE `$dbName`;");
    echo "Database created/selected successfully.\n\n";

    // Read and execute schema.sql
    echo "Importing schema.sql...\n";
    $schemaSql = file_get_contents(__DIR__ . '/schema.sql');
    
    // We execute the schema file. Since PDO exec doesn't handle multiple queries in some setups, we split by ';'
    // but schema.sql is simple, so we can execute it directly or run parts. PDO can run multiple statements at once if emulating is off/on,
    // but running directly is standard.
    $pdo->exec($schemaSql);
    echo "Schema imported successfully.\n\n";

    // Re-connect using our Core\Database class to ensure standard configuration
    echo "Seeding default data...\n";
    $db = \App\Core\Database::connect();

    // 1. Seed Roles
    $roles = [
        ['name' => 'Admin', 'description' => 'Administrator with full system privileges'],
        ['name' => 'Teacher', 'description' => 'Instructor who manages courses and grades students'],
        ['name' => 'Student', 'description' => 'Learner enrolled in courses'],
        ['name' => 'Parent', 'description' => 'Parent/Guardian viewing student progress']
    ];

    $roleIds = [];
    $stmtRole = $db->prepare("INSERT INTO roles (name, description) VALUES (:name, :description) ON DUPLICATE KEY UPDATE description = :update_description");
    foreach ($roles as $r) {
        $stmtRole->execute([
            'name' => $r['name'],
            'description' => $r['description'],
            'update_description' => $r['description']
        ]);
        $roleIds[$r['name']] = $db->lastInsertId() ?: $db->query("SELECT id FROM roles WHERE name = '{$r['name']}'")->fetchColumn();
        echo "Role seeded: {$r['name']}\n";
    }
    echo "\n";

    // 2. Seed Permissions
    $permissions = [
        ['name' => 'manage_users', 'description' => 'Create, edit, or delete users'],
        ['name' => 'manage_courses', 'description' => 'Create and modify courses/subjects'],
        ['name' => 'view_dashboard', 'description' => 'Access system dashboards'],
        ['name' => 'take_attendance', 'description' => 'Record student attendance'],
        ['name' => 'grade_assignments', 'description' => 'Grade quizzes and assignments'],
        ['name' => 'view_results', 'description' => 'View grades and transcripts'],
        ['name' => 'submit_assignments', 'description' => 'Submit homework or quizzes']
    ];

    $permIds = [];
    $stmtPerm = $db->prepare("INSERT INTO permissions (name, description) VALUES (:name, :description) ON DUPLICATE KEY UPDATE description = :update_description");
    foreach ($permissions as $p) {
        $stmtPerm->execute([
            'name' => $p['name'],
            'description' => $p['description'],
            'update_description' => $p['description']
        ]);
        $permIds[$p['name']] = $db->lastInsertId() ?: $db->query("SELECT id FROM permissions WHERE name = '{$p['name']}'")->fetchColumn();
        echo "Permission seeded: {$p['name']}\n";
    }
    echo "\n";

    // 3. Link Role and Permissions
    echo "Assigning permissions to roles...\n";
    $rolePermissions = [
        'Admin' => ['manage_users', 'manage_courses', 'view_dashboard', 'take_attendance', 'grade_assignments', 'view_results'],
        'Teacher' => ['view_dashboard', 'manage_courses', 'take_attendance', 'grade_assignments', 'view_results'],
        'Student' => ['view_dashboard', 'view_results', 'submit_assignments'],
        'Parent' => ['view_dashboard', 'view_results']
    ];

    $stmtRolePerm = $db->prepare("INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (:role_id, :permission_id)");
    foreach ($rolePermissions as $roleName => $perms) {
        $roleId = $roleIds[$roleName];
        foreach ($perms as $pName) {
            $permId = $permIds[$pName];
            $stmtRolePerm->execute(['role_id' => $roleId, 'permission_id' => $permId]);
        }
        echo "Assigned permissions to $roleName\n";
    }
    echo "\n";

    // 4. Seed Users
    echo "Seeding default users (Password: password123)...\n";
    $users = [
        [
            'name' => 'LMS Administrator',
            'email' => 'admin@lms.com',
            'password_hash' => password_hash('password123', PASSWORD_DEFAULT),
            'phone' => '+15550100',
            'role' => 'Admin'
        ],
        [
            'name' => 'Professor John Doe',
            'email' => 'teacher@lms.com',
            'password_hash' => password_hash('password123', PASSWORD_DEFAULT),
            'phone' => '+15550200',
            'role' => 'Teacher'
        ],
        [
            'name' => 'Jane Smith',
            'email' => 'student@lms.com',
            'password_hash' => password_hash('password123', PASSWORD_DEFAULT),
            'phone' => '+15550300',
            'role' => 'Student'
        ]
    ];

    $stmtUser = $db->prepare("INSERT INTO users (name, email, password_hash, phone, status) VALUES (:name, :email, :password_hash, :phone, 'active') ON DUPLICATE KEY UPDATE name = :update_name, password_hash = :update_password_hash");
    $stmtUserRole = $db->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (:user_id, :role_id)");

    foreach ($users as $u) {
        $stmtUser->execute([
            'name' => $u['name'],
            'email' => $u['email'],
            'password_hash' => $u['password_hash'],
            'phone' => $u['phone'],
            'update_name' => $u['name'],
            'update_password_hash' => $u['password_hash']
        ]);
        
        $userId = $db->lastInsertId() ?: $db->query("SELECT id FROM users WHERE email = '{$u['email']}'")->fetchColumn();
        $roleId = $roleIds[$u['role']];
        
        $stmtUserRole->execute(['user_id' => $userId, 'role_id' => $roleId]);
        echo "User created: {$u['name']} ({$u['email']}) [Role: {$u['role']}]\n";
    }

    echo "\n=========================================\n";
    echo "   Database setup completed successfully! \n";
    echo "=========================================\n";

} catch (Exception $e) {
    echo "\n[ERROR] Setup Failed: " . $e->getMessage() . "\n";
    exit(1);
}
